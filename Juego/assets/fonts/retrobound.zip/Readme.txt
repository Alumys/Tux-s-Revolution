English/French

Thanks for downloading RetroBound!

There are two ".ttf".
The first "RetroBound.ttf" contains the basic font with the lowercase letters.
The second "RetroBoundUC.ttf" contains the font with capital letters only, but the lowercase letters do not have the uppercase letters's decorations.

RetroBound is free for any use, personal or professional.

These did initially serve for a personal video game project, and I thought it could be used for other people for various uses! So i shared it.

It is not an obligation, but you can credit me on your works at the name "Exa" if you wish, it would be a great pleasure for me! :)

I hope it will be of good use to you!

I would be delighted to see your works, whatever it is. Do not hesitate to share your creations with me, I would be very happy!

If you would like to contact me: exacrus@gmail.com

Enjoy!


////\\\\

Merci d'avoir t�l�charg� RetroBound!

Il y a deux .ttf .
Le premier "RetroBound.ttf" contient la police de caract�re basique avec les lettres en minuscules.
La seconde "RetroBoundUC.ttf" contient la police de caract�re avec uniquement des majuscules, mais les lettres minuscules ne comportent pas les d�corations des lettres majuscules. 

RetroBound est gratuit pour n'importe quel usage, personnel ou professionnel.

Cette police de caract�re a au d�but servi pour un projet personnel de jeu vid�o, et je me suis dis qu'il pourrait servir � d'autres personnes pour diverses utilisations! Donc je l'ai partag�.

Ce n'est pas une obligation, mais vous pouvez me cr�diter sur vos oeuvres au nom de "Exa" si vous le souhaitez, �a me ferait extr�mement plaisir! :)

J'esp�re qu'il vous sera d'un bon usage!

Je serais ravie de voir vos �uvres, quel qu'elles soient. N'h�sitez pas � me partager vos cr�ations, j'en serais tr�s heureuse!

Si vous voulez me contacter: exacrus@gmail.com

Have fun !